# 微信公众号文章编辑器

一款简洁高效的在线微信公众号文章编辑器，支持多种精美模板，一键复制即可在微信中使用。

## ✨ 功能特点

### 📝 富文本编辑
- 基于 Quill.js 的所见即所得编辑
- 支持标题（H1-H3）、加粗、斜体、下划线、删除线
- 文字颜色、背景色、对齐方式
- 引用、有序/无序列表
- 插入图片、链接
- 多种字体和字号选择

### 🎨 5套精美模板
| 模板 | 风格 | 说明 |
|------|------|------|
| 经典蓝 | 商务专业 | 蓝色系，适合正式文章 |
| 素雅绿 | 清新文艺 | 绿色系，适合生活类文章 |
| 暖橘 | 温暖活力 | 橙色系，适合活动推广 |
| 墨韵 | 中国风 | 水墨系，适合文化类文章 |
| 极简灰 | 简约现代 | 灰色系，适合科技类文章 |

### 📱 手机预览
- 模拟 iPhone 外观的预览窗口
- 实时同步编辑内容
- 精准预览手机端显示效果

### 📋 微信兼容
- 一键转换并复制到剪贴板
- 自动处理微信不兼容的标签和样式
- 所有样式转换为内联样式
- 可直接粘贴到微信公众号后台使用

## 🚀 快速开始

### 方法一：直接在浏览器中打开
1. 下载或克隆本项目
2. 双击 `index.html` 文件
3. 在浏览器中直接使用

### 方法二：本地服务器
```bash
# 使用 Python 3
python -m http.server 8000

# 或使用 Node.js
npx serve .

# 然后访问 http://localhost:8000
```

## 📦 部署到 GitHub Pages

### 步骤 1：创建 GitHub 仓库
1. 登录 GitHub，点击右上角的 **+** 号，选择 **New repository**
2. 填写仓库名称（如 `wechat-editor`）
3. 选择 **Public**（公开仓库）
4. 点击 **Create repository**

### 步骤 2：上传文件
**方法A：使用 Git 命令行**
```bash
# 在项目文件夹中初始化 Git
git init

# 添加所有文件
git add .

# 提交
git commit -m "Initial commit"

# 添加远程仓库（替换为你的仓库地址）
git remote add origin https://github.com/你的用户名/wechat-editor.git

# 推送
git push -u origin master
```

**方法B：使用网页上传**
1. 在仓库页面点击 **uploading an existing file**
2. 将所有文件拖拽到上传区域
3. 点击 **Commit changes**

### 步骤 3：启用 GitHub Pages
1. 进入仓库的 **Settings**（设置）页面
2. 滚动到 **GitHub Pages** 部分
3. **Source** 选择 `master` 分支
4. 点击 **Save**
5. 等待几秒钟，你会看到绿色的提示显示你的网站地址：
   ```
   Your site is published at https://你的用户名.github.io/wechat-editor/
   ```

### 步骤 4：访问你的网站
打开浏览器访问上述地址即可使用编辑器！

## 📖 使用教程

### 基本编辑
1. 在左侧编辑区输入文章内容
2. 使用工具栏设置文字格式
3. 右侧预览区实时显示手机端效果

### 切换模板
1. 点击编辑区上方的模板选择器
2. 选择喜欢的模板风格
3. 模板样式会立即应用到预览区

### 发布到微信
1. 完成文章编辑
2. 点击右上角的 **「复制到微信」** 按钮
3. 打开微信公众号后台
4. 在编辑器中按 `Ctrl+V`（Windows）或 `Cmd+V`（Mac）粘贴
5. 格式将完整保留，可直接发布

## 🔧 技术说明

### 文件结构
```
微信编辑器/
├── index.html      # 主页面
├── style.css       # 页面样式
├── editor.js       # 编辑器逻辑
├── templates.js    # 模板定义
└── README.md       # 使用说明
```

### 技术栈
- **HTML5 + CSS3 + JavaScript**（纯原生，无框架）
- **Quill.js**（富文本编辑器，通过 CDN 加载）
- **纯 CSS 模板系统**（5 套精心设计的模板）

### 微信兼容处理
本编辑器针对微信公众号的 HTML 限制进行了特殊处理：

| 问题 | 解决方案 |
|------|----------|
| 微信过滤 style 标签 | 所有 CSS 转换为内联样式 |
| 微信过滤 div 标签 | 使用 section 标签替代 |
| 微信不支持 flex 布局 | 使用传统文档流布局 |
| 微信不支持部分 CSS | 只使用微信验证支持的属性 |
| 图片宽度溢出 | 强制 max-width: 100% |

### 微信支持的 CSS 属性（部分）
```
font-size, font-family, font-weight, font-style
color, background, background-color
text-align, text-decoration, text-indent, letter-spacing, line-height
margin, padding, border, border-radius, box-shadow
width, max-width, height, max-height
display, border-collapse
```

## ⚠️ 注意事项

1. **图片处理**：建议先上传图片到微信后台获取永久链接，再插入编辑器
2. **浏览器兼容**：推荐使用 Chrome、Safari、Firefox 等现代浏览器
3. **格式保留**：复制到微信后，建议检查一遍格式是否正确
4. **网络要求**：编辑器需要联网加载 Quill.js CDN

## 🐛 常见问题

### Q: 为什么复制到微信后格式错乱？
A: 请确保使用「复制到微信」按钮，不要直接复制编辑区的 HTML。如果仍有问题，请检查图片是否使用网络可访问的 URL。

### Q: 可以使用其他字体吗？
A: 可以选择 Quill 自带的字体选项。微信只支持少量预置字体，建议使用默认字体以保证兼容性。

### Q: 为什么预览和实际效果有差异？
A: 预览窗口模拟了 iPhone 的显示效果，但微信客户端可能有细微差异。最终效果以粘贴到微信公众号后台后为准。

## 📝 License

MIT License - 可自由使用、修改和分发。

---

**祝您创作愉快！** 🎉
